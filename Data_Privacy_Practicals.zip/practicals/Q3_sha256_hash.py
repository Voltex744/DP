# Q3. Function that takes a password and returns its SHA-256 hash
#     as a hexadecimal string.
# SHA-256 always gives a 256-bit hash = 64 hexadecimal characters.
# Hashing is ONE-WAY: we cannot get the password back from the hash.

import hashlib


def hash_password(password):
    encoded = password.encode()              # convert string to bytes
    hash_object = hashlib.sha256(encoded)    # apply SHA-256
    return hash_object.hexdigest()           # convert to hex string


# ---------------- Main Program ----------------
password = input("Enter a password: ")
hashed = hash_password(password)

print("\nSHA-256 Hash :", hashed)
print("Length       :", len(hashed), "characters")


"""
=====================================================================
                    EXPLANATION OF THE CODE
=====================================================================

WHAT IS HASHING?
----------------
A hash function takes any input (a password, a file, a whole book)
and gives a FIXED-SIZE output called the HASH (or "digest").

SHA-256 = Secure Hash Algorithm, 256-bit.
    - Output is always 256 bits = 32 bytes = 64 hexadecimal characters.
    - It does not matter if the input is 1 letter or 1 million letters,
      the output is always 64 characters long.

IMPORTANT PROPERTIES:
    1. ONE-WAY      : from the hash we cannot get the password back.
    2. DETERMINISTIC: same input -> always the same hash.
    3. AVALANCHE    : a tiny change ("hello" -> "Hello") gives a
                      completely different hash.
    4. COLLISION-RESISTANT : it is practically impossible to find two
                      different inputs that give the same hash.

WHY HASH PASSWORDS?
Websites should never store your real password. They store only its
hash. When you log in, they hash what you typed and compare the two
hashes. If the database is stolen, the attacker only gets hashes,
not the real passwords.


PART 1 : import hashlib
-----------------------
hashlib is a built-in Python library (no need to install it). It has
ready-made hash functions like md5, sha1 and sha256.


PART 2 : hash_password(password) FUNCTION
-----------------------------------------
1. encoded = password.encode()
   Hash functions work on BYTES, not on text (strings).
   .encode() changes the string into bytes (UTF-8 by default).
       "abc"  ->  b'abc'

2. hash_object = hashlib.sha256(encoded)
   Applies the SHA-256 algorithm to the bytes and gives a hash object.

3. return hash_object.hexdigest()
   .hexdigest() changes the hash into a readable string of hexadecimal
   characters (0-9 and a-f). This is the 64-character answer.
   (If we used .digest() instead, we would get raw bytes, which are
   hard to read.)


PART 3 : MAIN PROGRAM
---------------------
1. input() takes the password from the user.
2. hash_password() is called to get the hash.
3. The hash and its length (len(hashed) = 64) are printed.
   Printing the length shows that SHA-256 always gives 64 hex characters.


SAMPLE OUTPUT
-------------
Enter a password: hello123

SHA-256 Hash : 27cc6994fc1c01ce6659c6bddca9b69c4c6a9418065e612c69d110b3f7b11f8a
Length       : 64 characters

Try "hello124". Only one character changed, but the whole hash will
be different (the avalanche effect).


NOTE FOR VIVA
-------------
Plain SHA-256 is very FAST, so attackers can guess billions of
passwords per second. Real systems add a random SALT to each password
and use slow algorithms like bcrypt, scrypt, Argon2 or PBKDF2.
"""
