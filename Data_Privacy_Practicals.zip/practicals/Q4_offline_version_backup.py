# Q4. Read a file of "username,password" pairs and check whether each
#     password has been leaked in a data breach.
#
# This program works in TWO ways:
#   1. ONLINE  : uses the Have I Been Pwned (HIBP) "Pwned Passwords" API
#                (https://api.pwnedpasswords.com/range/<first 5 chars>)
#   2. OFFLINE : if there is no internet, it checks the passwords against a
#                local file of known leaked passwords (leaked_passwords.txt)
#
# No extra installation is needed. We use 'urllib', which is BUILT INTO
# Python, instead of 'requests'.
#
# Run:  python Q4_check_pwned_passwords.py

import hashlib
import urllib.request


# ---------- Common helper: make the SHA-1 hash of a password ----------
def sha1_hash(password):
    return hashlib.sha1(password.encode()).hexdigest().upper()


# ---------- METHOD 1 : ONLINE check using the HIBP API ----------
def check_online(password):
    hash_value = sha1_hash(password)
    prefix = hash_value[:5]          # only these 5 characters are sent
    suffix = hash_value[5:]          # these 35 characters stay on our computer

    url = "https://api.pwnedpasswords.com/range/" + prefix
    request = urllib.request.Request(url, headers={"User-Agent": "Python-Practical"})
    with urllib.request.urlopen(request, timeout=10) as response:
        data = response.read().decode()        # bytes -> text

    for line in data.splitlines():
        hash_suffix, count = line.split(":")
        if hash_suffix == suffix:
            return int(count)        # leaked this many times
    return 0                         # not leaked


# ---------- METHOD 2 : OFFLINE check using a local file ----------
def load_leaked_hashes(filename):
    leaked = set()
    with open(filename, "r") as file:
        for line in file:
            word = line.strip()
            if word != "":
                leaked.add(sha1_hash(word))    # store the HASH, not the password
    return leaked


def check_offline(password, leaked_hashes):
    return sha1_hash(password) in leaked_hashes    # True = leaked


# ---------- Find out whether internet / API is available ----------
def internet_available():
    try:
        check_online("test")
        return True
    except Exception:
        return False


# ---------------- Main Program ----------------
filename = input("Enter credentials file (default: credentials.txt): ") or "credentials.txt"

if internet_available():
    mode = "ONLINE"
    print("\nInternet found -> checking with Have I Been Pwned API\n")
else:
    mode = "OFFLINE"
    print("\nNo internet -> checking with local file leaked_passwords.txt\n")
    try:
        leaked_hashes = load_leaked_hashes("leaked_passwords.txt")
    except FileNotFoundError:
        print("leaked_passwords.txt not found. Cannot check offline.")
        exit()

try:
    with open(filename, "r") as file:
        for line in file:
            line = line.strip()
            if line == "" or "," not in line:
                continue
            username, password = line.split(",", 1)
            username = username.strip()
            password = password.strip()

            if mode == "ONLINE":
                count = check_online(password)
                if count > 0:
                    print(f"{username:<10} -> LEAKED! Found {count} times in data breaches")
                else:
                    print(f"{username:<10} -> SAFE. Not found in any known breach")
            else:
                if check_offline(password, leaked_hashes):
                    print(f"{username:<10} -> LEAKED! Found in local leaked-password list")
                else:
                    print(f"{username:<10} -> SAFE. Not found in local list")

except FileNotFoundError:
    print("File not found:", filename)


"""
=====================================================================
                    EXPLANATION OF THE CODE
=====================================================================

WHAT DOES THIS PROGRAM DO?
--------------------------
It reads usernames and passwords from a file and tells us which
passwords have been leaked in data breaches (hacked websites).
It has TWO methods:
    ONLINE  -> asks the real Have I Been Pwned (HIBP) database.
    OFFLINE -> checks against a list of leaked passwords saved on
               our own computer (leaked_passwords.txt).
The program checks the internet by itself and picks the right method.


WHY urllib INSTEAD OF requests?
-------------------------------
'requests' is NOT part of Python. It must be installed with pip, and
installing it also needs internet.
'urllib' is BUILT INTO Python, so it always works with no installation.
Both do the same job here: they send a GET request to a URL and read
the reply.

    requests version              urllib version
    ----------------              --------------
    requests.get(url)             urllib.request.urlopen(url)
    response.text                 response.read().decode()


WHAT IS "HAVE I BEEN PWNED" (HIBP)?
-----------------------------------
HIBP is a website made by security researcher Troy Hunt. It collects
passwords from real data breaches. Its "Pwned Passwords" API is free
and needs no API key. ("Pwned" is slang for "owned", meaning hacked.)


HOW THE ONLINE CHECK KEEPS THE PASSWORD PRIVATE (K-ANONYMITY)
------------------------------------------------------------
We NEVER send the password, or even its full hash.
Example password: "password123"

Step 1: Make the SHA-1 hash in UPPERCASE.
        CBFDAC6008F9CAB4083784CBD1874F76618D2A97
Step 2: Split it into two parts.
        prefix (first 5)  = CBFDA
        suffix (last 35)  = C6008F9CAB4083784CBD1874F76618D2A97
Step 3: Send ONLY the prefix:
        https://api.pwnedpasswords.com/range/CBFDA
Step 4: The API sends back every leaked hash suffix that starts with
        CBFDA (hundreds of lines) in the form  SUFFIX:COUNT
Step 5: Our own computer checks whether our suffix is in that list.

The server only sees "CBFDA", which matches hundreds of passwords, so
it cannot know which one we checked.


PART 1 : IMPORTS
----------------
import hashlib        -> to make the SHA-1 hash (built in).
import urllib.request -> to send the web request (built in).


PART 2 : sha1_hash(password)
----------------------------
    password.encode() -> string to bytes (hash functions need bytes)
    hashlib.sha1(...) -> applies the SHA-1 hash
    .hexdigest()      -> makes it a readable hex string
    .upper()          -> UPPERCASE, because HIBP uses uppercase
Both methods use this function, so the code is not repeated.


PART 3 : check_online(password)  -> METHOD 1
--------------------------------------------
1. hash_value[:5]  = prefix (first 5 characters)
   hash_value[5:]  = suffix (the remaining 35 characters)

2. urllib.request.Request(url, headers={"User-Agent": ...})
   Builds the request. The "User-Agent" header tells the server which
   program is asking. HIBP rejects requests that do not have one.

3. urllib.request.urlopen(request, timeout=10)
   Sends the request and waits for up to 10 seconds.
   If there is no internet, this line raises an ERROR. We use that
   error later to detect that we are offline.

4. response.read().decode()
   read() gives the reply as BYTES, and decode() changes it to text.

5. for line in data.splitlines():
       hash_suffix, count = line.split(":")
   Each line looks like "SUFFIX:COUNT", so we split it at ":".

6. If our suffix matches, return the count. If the loop ends without
   a match, return 0 (not leaked).


PART 4 : load_leaked_hashes(filename)  -> METHOD 2 (setup)
---------------------------------------------------------
1. Opens leaked_passwords.txt (one leaked password per line).
2. For every password in the file, it makes the SHA-1 HASH and stores
   the hash in a SET.
   - Why store hashes? Real breach databases (like HIBP) store hashes,
     not plain passwords, so we copy the same idea.
   - Why a SET? Searching a set is very fast (it does not check items
     one by one like a list does).


PART 5 : check_offline(password, leaked_hashes)  -> METHOD 2 (check)
--------------------------------------------------------------------
    return sha1_hash(password) in leaked_hashes
Hash the user's password and check whether that hash is in the set.
True means leaked, False means safe.
We compare HASHES, not the plain passwords, just like a real system.


PART 6 : internet_available()
-----------------------------
It tries one online check with the word "test".
    - If it works       -> return True  (we are online)
    - If any error comes (no internet, website blocked, timeout)
                        -> 'except' catches it -> return False (offline)
This is how the program decides the mode by itself.


PART 7 : MAIN PROGRAM
---------------------
1. Asks for the credentials file. Pressing Enter uses
   "credentials.txt" (empty input "" is False, so 'or' picks the default).

2. Calls internet_available() and sets mode = "ONLINE" or "OFFLINE".
   In OFFLINE mode, it loads leaked_passwords.txt. If that file is
   missing, it prints a message and stops with exit().

3. Reads the credentials file line by line:
     line.strip()          -> removes spaces and "\n"
     skip empty lines or lines without a comma
     line.split(",", 1)    -> splits at the FIRST comma only
                              "alice,password123" -> "alice", "password123"

4. Checks each password with the right method and prints LEAKED or SAFE.
   f"{username:<10}" makes the name 10 characters wide and
   left-aligned, so the output looks like a neat table.

5. 'except FileNotFoundError' shows a clear message if the credentials
   file name is wrong.


FILES USED
----------
credentials.txt       -> usernames and passwords to check
leaked_passwords.txt  -> offline list of commonly leaked passwords
                         (you can add more, one per line)


SAMPLE OUTPUT (OFFLINE - no internet)
-------------------------------------
Enter credentials file (default: credentials.txt):

No internet -> checking with local file leaked_passwords.txt

alice      -> LEAKED! Found in local leaked-password list
bob        -> LEAKED! Found in local leaked-password list
charlie    -> SAFE. Not found in local list
david      -> LEAKED! Found in local leaked-password list
eve        -> SAFE. Not found in local list


SAMPLE OUTPUT (ONLINE - the exact counts depend on the live HIBP data)
-------------------------------------------------------------------
Internet found -> checking with Have I Been Pwned API

alice      -> LEAKED! Found <some number> times in data breaches
bob        -> LEAKED! Found <some number> times in data breaches
charlie    -> SAFE. Not found in any known breach
david      -> LEAKED! Found <some number> times in data breaches
eve        -> SAFE. Not found in any known breach


NOTE FOR VIVA
-------------
- ONLINE is better: HIBP has hundreds of millions of leaked passwords.
  OFFLINE only knows the passwords in our small file.
- The full HIBP database can also be downloaded for offline use, but
  it is many gigabytes. That is why we use a small sample list here.
- SHA-1 is used here only to look things up (like an ID). It is not
  used to protect the password.
"""
