# Q6. Simulate a brute-force attack on a password by trying
#     ALL possible character combinations.
# The program tries: a, b, c, ..., aa, ab, ... until it finds the password.
# NOTE: Use only SHORT passwords (1-4 characters), because the number of
#       combinations grows very fast:  total = (characters) ^ (length)

import itertools
import string
import time

# Characters the attacker will try (lowercase + digits = 36 characters)
characters = string.ascii_lowercase + string.digits


def brute_force(password, max_length=5):
    attempts = 0
    for length in range(1, max_length + 1):
        # product() gives every combination of 'length' characters
        for combo in itertools.product(characters, repeat=length):
            attempts += 1
            guess = "".join(combo)
            if guess == password:
                return guess, attempts
    return None, attempts


# ---------------- Main Program ----------------
password = input("Enter a password to crack (use a-z, 0-9, max 4-5 chars): ").lower()

print("\nStarting brute-force attack...")
start = time.time()
found, attempts = brute_force(password)
end = time.time()

if found:
    print("Password FOUND  :", found)
else:
    print("Password not found (too long or has other characters)")
print("Total attempts  :", attempts)
print("Time taken      : %.4f seconds" % (end - start))


"""
=====================================================================
                    EXPLANATION OF THE CODE
=====================================================================

WHAT IS A BRUTE-FORCE ATTACK?
-----------------------------
The attacker does not know the password, so they try EVERY possible
combination one by one until one matches:
    a, b, c, ..., z, 0, ..., 9,
    aa, ab, ac, ..., 99,
    aaa, aab, ... and so on.
It ALWAYS finds the password in the end, but it can take a very long
time if the password is long.

TOTAL COMBINATIONS = (number of characters) ^ (password length)
With 36 characters (a-z + 0-9):
    length 1 ->            36
    length 2 ->         1,296
    length 3 ->        46,656
    length 4 ->     1,679,616
    length 6 ->  2,176,782,336   (2 billion)
    length 8 -> 2,821,109,907,456 (2.8 trillion)
Each extra character makes it 36 times harder. This is why LONG
passwords are safe. If we also use capitals and symbols (about 95
characters), it becomes even harder.


PART 1 : IMPORTS
----------------
itertools -> has product(), which makes all combinations for us.
string    -> has ready-made character sets:
               string.ascii_lowercase = "abcdefghijklmnopqrstuvwxyz"
               string.digits          = "0123456789"
time      -> to measure how long the attack takes.

characters = string.ascii_lowercase + string.digits
   These are the 36 characters the attacker will try.


PART 2 : brute_force(password, max_length=5) FUNCTION
-----------------------------------------------------
1. attempts = 0  -> counts how many guesses we make.

2. for length in range(1, max_length + 1):
   First try all 1-letter guesses, then all 2-letter guesses, and so on
   up to max_length (5). Short passwords are found first.

3. for combo in itertools.product(characters, repeat=length):
   product() gives EVERY combination of 'length' characters.
   It is like a car's odometer (meter):
       repeat=2 -> ('a','a'), ('a','b'), ..., ('a','9'), ('b','a'), ...
   It works like 'length' nested for-loops, but in one line.

4. attempts += 1  -> one more guess was made.

5. guess = "".join(combo)
   combo is a tuple like ('a','b','c'). join() makes it the string "abc".

6. if guess == password: return guess, attempts
   Found it! Return the password and the number of tries.
   (A function can return two values together as a tuple.)

7. return None, attempts
   If all lengths were tried and nothing matched (the password was too
   long or had capitals/symbols), return None.


PART 3 : MAIN PROGRAM
---------------------
1. password = input(...).lower()
   Takes the password and makes it lowercase, because our character
   set only has small letters.

2. start = time.time()  -> notes the start time (in seconds).
   found, attempts = brute_force(password)  -> runs the attack.
   end = time.time()  -> notes the end time.
   end - start = time taken.

3. if found: -> prints the cracked password.
   else:     -> prints "not found".

4. Prints the total attempts and the time.
   "%.4f" % value prints the number with 4 digits after the decimal point.


SAMPLE OUTPUT
-------------
Enter a password to crack (use a-z, 0-9, max 4-5 chars): abc1

Starting brute-force attack...
Password FOUND  : abc1
Total attempts  : 49384
Time taken      : 0.0047 seconds

Why 49,384 attempts?
    all 1-char guesses : 36
    all 2-char guesses : 1,296
    all 3-char guesses : 46,656
    4-char guesses up to "abc1" : 1,396
    Total = 36 + 1296 + 46656 + 1396 = 49,384


HOW TO PROTECT AGAINST BRUTE FORCE (useful for viva)
----------------------------------------------------
1. Use LONG passwords (12+ characters).
2. Use a mix of capitals, small letters, digits and symbols.
3. Lock the account after a few wrong tries, or add a delay
   (rate limiting).
4. Use CAPTCHA and Two-Factor Authentication (2FA).
5. Store passwords with SLOW hashes (bcrypt/Argon2) plus a salt.
"""
