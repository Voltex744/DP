# Q1. Encryption and Decryption using Caesar Cipher (Substitution Cipher)
# Idea: every letter is shifted forward by 'key' places in the alphabet.
#       Example (key = 3): A -> D, B -> E, ..., X -> A, Y -> B, Z -> C

def encrypt(text, key):
    result = ""
    for ch in text:
        if ch.isupper():                       # Capital letters
            result += chr((ord(ch) - 65 + key) % 26 + 65)
        elif ch.islower():                     # Small letters
            result += chr((ord(ch) - 97 + key) % 26 + 97)
        else:                                  # Spaces, digits, symbols unchanged
            result += ch
    return result


def decrypt(cipher, key):
    # Decryption = shifting backwards by the same key
    return encrypt(cipher, -key)


# ---------------- Main Program ----------------
text = input("Enter the plain text : ")
key = int(input("Enter the key (shift): "))

cipher_text = encrypt(text, key)
print("\nEncrypted Text :", cipher_text)

plain_text = decrypt(cipher_text, key)
print("Decrypted Text :", plain_text)


"""
=====================================================================
                    EXPLANATION OF THE CODE
=====================================================================

WHAT IS CAESAR CIPHER?
----------------------
It is one of the oldest and simplest encryption methods (used by
Julius Caesar). It is a SUBSTITUTION cipher, which means every letter
is REPLACED by another letter. The new letter is found by moving
(shifting) a fixed number of places forward in the alphabet.
That fixed number is called the KEY.

    Key = 3
    Plain  : A B C D E F G ... X Y Z
    Cipher : D E F G H I J ... A B C

After Z we go back to A (it wraps around like a circle).

FORMULAS:
    Encryption :  C = (P + K) mod 26
    Decryption :  P = (C - K) mod 26
where P = position of the plain letter (A=0, B=1, ..., Z=25),
      C = position of the cipher letter, K = key.


PART 1 : encrypt(text, key) FUNCTION
------------------------------------
1. result = ""  -> an empty string where we build the answer.

2. for ch in text:  -> we go through the text one character at a time.

3. if ch.isupper():  (capital letter A-Z)
       chr((ord(ch) - 65 + key) % 26 + 65)
   Let us break this down using ch = 'Y' and key = 3:
     - ord(ch)       : gives the ASCII number of the letter.
                       ord('Y') = 89
     - ord(ch) - 65  : changes it to a position 0-25
                       ('A' is 65). 89 - 65 = 24  (Y is 24th, A is 0th)
     - + key         : shifts it forward. 24 + 3 = 27
     - % 26          : wraps it around if it goes past Z.
                       27 % 26 = 1
     - + 65          : changes the position back to ASCII. 1 + 65 = 66
     - chr(66)       : changes the number back to a letter = 'B'
   So 'Y' becomes 'B'. 

4. elif ch.islower():  (small letter a-z)
   Same steps, but 97 is used because ord('a') = 97.
   This way small letters stay small and capital letters stay capital.

5. else:  -> spaces, digits and symbols (like !, 5, @) are added as
   they are, without any change.

6. return result  -> sends back the encrypted text.


PART 2 : decrypt(cipher, key) FUNCTION
--------------------------------------
To decrypt, we must shift BACKWARDS by the same key.
Shifting backwards by 3 is the same as shifting forward by -3, so we
simply call:   encrypt(cipher, -key)

Why does it work with negative numbers? In Python, % always gives
a positive answer, e.g. (1 - 3) % 26 = -2 % 26 = 24.
So 'B' (1) goes back to 'Y' (24). The wrap-around also works backwards.
This means we do not need to write a second loop.


PART 3 : MAIN PROGRAM
---------------------
1. input() takes the plain text from the user.
2. int(input()) takes the key and changes it from a string to an
   integer, because we need to do maths with it.
3. encrypt() is called and the cipher text is printed.
4. decrypt() is called on that cipher text and the original text
   is printed again. This proves both functions are correct.


SAMPLE OUTPUT
-------------
Enter the plain text : Hello World
Enter the key (shift): 3

Encrypted Text : Khoor Zruog
Decrypted Text : Hello World


WEAKNESS (useful for viva)
--------------------------
There are only 25 useful keys, so an attacker can simply try all 25
(a brute-force attack) and break it in seconds. Also, the same letter
always becomes the same cipher letter, so it can be broken by
FREQUENCY ANALYSIS (for example, 'E' is the most common letter in English).
"""
