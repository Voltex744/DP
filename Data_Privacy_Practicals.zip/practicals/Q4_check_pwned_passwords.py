# Q4. Check if passwords from a file have been leaked in a data breach
#     using the Have I Been Pwned (HIBP) API.
# Needs internet and the requests library:  pip install requests

import hashlib
import requests


def check_password(password):
    sha1 = hashlib.sha1(password.encode()).hexdigest().upper()
    prefix, suffix = sha1[:5], sha1[5:]

    response = requests.get("https://api.pwnedpasswords.com/range/" + prefix)

    for line in response.text.splitlines():
        hash_suffix, count = line.split(":")
        if hash_suffix == suffix:
            return int(count)
    return 0


file = open("credentials.txt", "r")
for line in file:
    username, password = line.strip().split(",")
    count = check_password(password)
    if count > 0:
        print(username, "-> LEAKED", count, "times")
    else:
        print(username, "-> SAFE")
file.close()


"""
=====================================================================
                    EXPLANATION OF THE CODE
=====================================================================

WHAT DOES THIS PROGRAM DO?
--------------------------
It reads usernames and passwords from credentials.txt (one
"username,password" per line) and uses the free Have I Been Pwned
(HIBP) API to check whether each password has been leaked in a data
breach. ("Pwned" is slang for "hacked".) No API key is needed.


HOW IT KEEPS THE PASSWORD PRIVATE (K-ANONYMITY)
-----------------------------------------------
We never send the real password, or even its full hash.
  1. Make the SHA-1 hash of the password (UPPERCASE).
       "password123" -> CBFDAC6008F9CAB4083784CBD1874F76618D2A97
  2. Send ONLY the first 5 characters (CBFDA) to the API.
  3. The API returns every leaked hash that starts with CBFDA, as
     lines of the form "REMAINING_35_CHARS:COUNT".
  4. Our computer checks whether our remaining 35 characters are in
     that list.
The server only sees 5 characters, which match hundreds of passwords,
so it cannot know which password we checked.


PART 1 : IMPORTS
----------------
hashlib  -> to make the SHA-1 hash (built into Python)
requests -> to send the request to the website (install with pip)


PART 2 : check_password(password) FUNCTION
------------------------------------------
1. sha1 = hashlib.sha1(password.encode()).hexdigest().upper()
     .encode()    -> changes the text to bytes (hashing needs bytes)
     sha1(...)    -> makes the SHA-1 hash
     .hexdigest() -> changes it to a readable hex string
     .upper()     -> UPPERCASE, because the API uses uppercase

2. prefix, suffix = sha1[:5], sha1[5:]
     prefix = first 5 characters      (this is sent to the API)
     suffix = the other 35 characters (this stays on our computer)
   Both values are set in one line.

3. response = requests.get(URL + prefix)
   Sends the request. The reply text is in response.text.

4. for line in response.text.splitlines():
       hash_suffix, count = line.split(":")
   splitlines() gives one line at a time. split(":") separates
   the hash part and the count.

5. if hash_suffix == suffix: return int(count)
   Our hash is found, so the password is leaked. Return how many times.

6. return 0
   It was not found anywhere, so the password is safe.


PART 3 : MAIN PROGRAM
---------------------
1. open("credentials.txt", "r") opens the file for reading.

2. for line in file:  reads it one line at a time.

3. line.strip().split(",")
     .strip()    -> removes the newline "\n" at the end
     .split(",") -> "alice,password123" becomes ["alice", "password123"]
   Then these two values are stored in username and password.

4. check_password() is called. If count > 0, it prints LEAKED,
   otherwise SAFE.

5. file.close() closes the file at the end.


INPUT FILE (credentials.txt)
----------------------------
alice,password123
bob,qwerty
charlie,Xy7#pL9!vQ2@mK4z
david,iloveyou
eve,Tr0ub4dor&3_Horse!Battery


SAMPLE OUTPUT (the counts depend on the live HIBP data)
-------------------------------------------------------
alice -> LEAKED <some number> times
bob -> LEAKED <some number> times
charlie -> SAFE
david -> LEAKED <some number> times
eve -> SAFE

Note: the file must not have empty lines, and each line needs exactly
one comma.
"""
