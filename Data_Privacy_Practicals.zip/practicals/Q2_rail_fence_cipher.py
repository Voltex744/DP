# Q2. Encryption and Decryption using Rail Fence Cipher (Transposition Cipher)
# Idea: write the message in a zig-zag pattern on 'rails' rows,
#       then read row by row to get the cipher text.
#
# Example: "HELLOWORLD" with 3 rails
#   H . . . O . . . L .
#   . E . L . W . R . D
#   . . L . . . O . . .
#   Cipher = HOL + ELWRD + LO = "HOLELWRDLO"

def encrypt(text, rails):
    if rails == 1:
        return text
    fence = [""] * rails           # one string for each rail
    row = 0
    step = 1                       # +1 means going down, -1 means going up
    for ch in text:
        fence[row] += ch
        if row == 0:
            step = 1
        elif row == rails - 1:
            step = -1
        row += step
    return "".join(fence)


def decrypt(cipher, rails):
    if rails == 1:
        return cipher
    n = len(cipher)

    # Step 1: find which rail each position of the message belongs to
    pattern = []
    row, step = 0, 1
    for i in range(n):
        pattern.append(row)
        if row == 0:
            step = 1
        elif row == rails - 1:
            step = -1
        row += step

    # Step 2: count letters on each rail and cut the cipher into pieces
    counts = [pattern.count(r) for r in range(rails)]
    pieces = []
    start = 0
    for c in counts:
        pieces.append(list(cipher[start:start + c]))
        start += c

    # Step 3: read in zig-zag order again, taking letters from each rail
    result = ""
    for r in pattern:
        result += pieces[r].pop(0)
    return result


# ---------------- Main Program ----------------
text = input("Enter the plain text   : ")
rails = int(input("Enter number of rails : "))

cipher_text = encrypt(text, rails)
print("\nEncrypted Text :", cipher_text)

plain_text = decrypt(cipher_text, rails)
print("Decrypted Text :", plain_text)


"""
=====================================================================
                    EXPLANATION OF THE CODE
=====================================================================

WHAT IS RAIL FENCE CIPHER?
--------------------------
It is a TRANSPOSITION cipher. The letters are NOT changed. Only their
ORDER (position) is changed.
(Caesar = substitution = letters change.
 Rail Fence = transposition = positions change.)

We write the message in a zig-zag (diagonal) way on a number of rows,
called "rails". We go down to the last rail, then come back up to the
first rail, then go down again, and so on.
Then we read the rails one by one, from top to bottom, to get the cipher.

Example : "HELLOWORLD", rails = 3

    Rail 0 :  H . . . O . . . L .
    Rail 1 :  . E . L . W . R . D
    Rail 2 :  . . L . . . O . . .

    Read rail 0 -> HOL
    Read rail 1 -> ELWRD
    Read rail 2 -> LO
    Cipher text = "HOLELWRDLO"


PART 1 : encrypt(text, rails) FUNCTION
--------------------------------------
1. if rails == 1: return text
   With only one rail there is no zig-zag, so the text stays the same.
   (This also stops an error, because the "bounce" logic needs 2+ rails.)

2. fence = [""] * rails
   Makes a list of empty strings, one for each rail.
   For 3 rails: fence = ["", "", ""]

3. row = 0   -> we start writing on the top rail.
   step = 1  -> +1 means "move down", -1 means "move up".

4. for ch in text:
     fence[row] += ch    -> put the current letter on the current rail.

     if row == 0: step = 1
        -> at the top rail, we must start going DOWN.
     elif row == rails - 1: step = -1
        -> at the bottom rail, we must start going UP.

     row += step  -> move to the next rail.

   Rows visited for 3 rails:  0,1,2,1,0,1,2,1,0,1 ...  (the zig-zag)

5. return "".join(fence)
   Joins all rails together, top to bottom = the cipher text.
   For our example: "HOL" + "ELWRD" + "LO" = "HOLELWRDLO"


PART 2 : decrypt(cipher, rails) FUNCTION
----------------------------------------
Decryption is harder, because from the cipher alone we do not know
where one rail ends and the next one starts. So we do it in 3 steps.

STEP 1 : Make the zig-zag PATTERN.
   Using the same up/down logic, we record which rail each position
   of the message belongs to (without letters, only rail numbers).
   For 10 letters and 3 rails:
       pattern = [0, 1, 2, 1, 0, 1, 2, 1, 0, 1]

STEP 2 : Count letters on each rail and CUT the cipher.
   counts = [pattern.count(r) for r in range(rails)]
       Rail 0 appears 3 times, rail 1 appears 5 times, rail 2 appears 2.
       counts = [3, 5, 2]
   Now we cut the cipher "HOLELWRDLO" into pieces of these sizes:
       Rail 0 -> "HOL"
       Rail 1 -> "ELWRD"
       Rail 2 -> "LO"
   Each piece is stored as a list so we can take letters out one by one.
   'start' remembers where the next piece begins.

STEP 3 : Read in zig-zag order.
   for r in pattern:
       result += pieces[r].pop(0)
   We walk through the pattern again. At each position we take the
   FIRST remaining letter (pop(0)) from that rail.
       pattern 0 -> take 'H' from rail 0
       pattern 1 -> take 'E' from rail 1
       pattern 2 -> take 'L' from rail 2
       pattern 1 -> take 'L' from rail 1
       pattern 0 -> take 'O' from rail 0  ... and so on
   Result = "HELLOWORLD". The original message is back.


PART 3 : MAIN PROGRAM
---------------------
1. Takes the plain text and the number of rails (the KEY) from the user.
2. Calls encrypt() and prints the cipher text.
3. Calls decrypt() on the cipher text and prints the original text.


SAMPLE OUTPUT
-------------
Enter the plain text   : HELLOWORLD
Enter number of rails : 3

Encrypted Text : HOLELWRDLO
Decrypted Text : HELLOWORLD


WEAKNESS (useful for viva)
--------------------------
The key (number of rails) can only be from 2 to (length of text - 1),
so an attacker can try every value very quickly. Also, the letters are
not changed, so the letter frequencies of the cipher are the same as in
normal English, which shows that a transposition cipher was used.
"""
