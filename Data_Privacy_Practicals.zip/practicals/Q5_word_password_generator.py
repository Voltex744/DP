# Q5. Generate a password using a random combination of words
#     from a dictionary file (words.txt - one word per line).
# Example output:  Tiger-Ocean-Pencil-Rocket47

import secrets   # secrets is safer than random for passwords


def load_words(filename):
    words = []
    with open(filename, "r") as file:
        for line in file:
            word = line.strip()
            if word != "":
                words.append(word)
    return words


def generate_password(words, num_words=4, separator="-"):
    chosen = []
    for i in range(num_words):
        word = secrets.choice(words)          # pick a random word
        chosen.append(word.capitalize())      # first letter capital
    number = secrets.randbelow(100)           # random number 0-99
    return separator.join(chosen) + str(number)


# ---------------- Main Program ----------------
filename = input("Enter dictionary file (default: words.txt): ") or "words.txt"
n = int(input("How many words in the password? "))

try:
    words = load_words(filename)
    print("Total words loaded:", len(words))
    password = generate_password(words, n)
    print("\nGenerated Password:", password)
except FileNotFoundError:
    print("File not found:", filename)


"""
=====================================================================
                    EXPLANATION OF THE CODE
=====================================================================

WHAT IS A WORD-BASED PASSWORD (PASSPHRASE)?
-------------------------------------------
Instead of a hard password like "x7#Kp2!q", we join several random
words, e.g. "Tiger-Ocean-Pencil-Rocket47".
    - It is EASY for humans to remember.
    - It is HARD for computers to guess, because it is long and the
      words are chosen randomly.
This idea is also called "Diceware".

HOW STRONG IS IT?
If the dictionary has N words and we pick K words, the number of
possible passwords = N ^ K.
    30 words, 4 words picked -> 30^4 = 810,000 (x100 for the number)
    7776 words (real Diceware list), 4 words -> about 3.6 trillion
So a BIGGER dictionary and MORE words make the password much stronger.


PART 1 : import secrets
-----------------------
We use 'secrets' and NOT 'random'.
    - random  : predictable. Good for games, NOT for security.
    - secrets : uses the operating system's secure random generator.
                It is made for passwords, tokens and keys.


PART 2 : load_words(filename) FUNCTION
--------------------------------------
1. words = []  -> an empty list to store the words.
2. with open(filename, "r") as file:  -> open the dictionary file.
3. for line in file:
       word = line.strip()  -> remove the newline "\n" and spaces.
       if word != "": words.append(word)  -> skip empty lines.
4. return words  -> a list like ["apple", "banana", "tiger", ...]


PART 3 : generate_password(words, num_words=4, separator="-")
-------------------------------------------------------------
num_words=4 and separator="-" are DEFAULT values. They are used if
the caller does not give them.

1. chosen = []  -> list to hold the chosen words.

2. for i in range(num_words):
       word = secrets.choice(words)    -> pick ONE random word
       chosen.append(word.capitalize())
   .capitalize() makes the first letter capital: "tiger" -> "Tiger".
   This adds uppercase letters, which most websites require.
   (The same word can be picked twice. That is normal and allowed.)

3. number = secrets.randbelow(100)
   Gives a random number from 0 to 99. It adds digits to the password.

4. return separator.join(chosen) + str(number)
   join() puts "-" between the words:
       ["Tiger","Ocean","Pencil","Rocket"] -> "Tiger-Ocean-Pencil-Rocket"
   str(number) changes the number to a string so it can be added:
       final password -> "Tiger-Ocean-Pencil-Rocket47"
   Now the password has uppercase letters, lowercase letters, digits
   and a symbol (-).


PART 4 : MAIN PROGRAM
---------------------
1. Asks for the file name. Pressing Enter uses "words.txt"
   (the 'or' trick: empty input "" is False).
2. Asks how many words to use and changes it to an int.
3. Loads the words, prints how many were loaded, then generates and
   prints the password.
4. If the file does not exist, FileNotFoundError is caught and a
   friendly message is shown instead of a crash.


DICTIONARY FILE (words.txt)
---------------------------
One word per line (30 words are given). You can add more words to
make the passwords stronger.


SAMPLE OUTPUT (different every time, because it is random)
----------------------------------------------------------
Enter dictionary file (default: words.txt):
How many words in the password? 4
Total words loaded: 30

Generated Password: Yellow-Island-Banana-Sunset91
"""
